package epiModel;

public enum Age {
	YOUNG, OLD

}
