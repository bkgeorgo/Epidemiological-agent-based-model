package epiModel;

public enum Health_Status {
 SUSCEPTIBLE, INFECTED, RECOVERED, }
